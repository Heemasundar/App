package com.saveetha.tricholens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts

class DashboardActivity : AppCompatActivity() {

    // Image Picker
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val selectedImageUri: Uri? = result.data?.data
                selectedImageUri?.let {
                    // TODO: Handle selected image here
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val profileContainer = findViewById<LinearLayout>(R.id.profileContainer)
        val uploadContainer = findViewById<LinearLayout>(R.id.uploadContainer)
        val historyContainer = findViewById<LinearLayout>(R.id.historyContainer)
        val usernameText = findViewById<TextView>(R.id.usernameText)

        // Profile (icon)
        profileContainer.setOnClickListener {
            startActivity(Intent(this, ViewProfileActivity::class.java))
        }

        // Upload image from gallery
        uploadContainer.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.type = "image/*"
            pickImage.launch(intent)
        }

        // Profile (text)
        usernameText.setOnClickListener {
            startActivity(Intent(this, ViewProfileActivity::class.java))
        }

        // History
        historyContainer.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }
}
