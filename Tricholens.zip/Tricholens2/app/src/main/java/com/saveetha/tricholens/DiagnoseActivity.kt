package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DiagnoseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnose)

        // Find Diagnose button
        val diagnoseButton = findViewById<Button>(R.id.diagnoseButton)

        // Diagnose → Go to ObjectDetectedActivity
        diagnoseButton.setOnClickListener {
            val intent = Intent(this, ObjectDetectedActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
