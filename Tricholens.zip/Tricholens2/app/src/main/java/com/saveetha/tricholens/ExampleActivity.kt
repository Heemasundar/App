package com.saveetha.tricholens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ExampleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout. Explicitly type View to avoid setContentView ambiguity.
        val view: View = LayoutInflater.from(this).inflate(R.layout.item_image, null)

        // Access imageView inside the inflated layout if needed
        val imageView = view.findViewById<ImageView>(R.id.imageItem)

        // Optionally set properties on imageView here

        // Set the inflated view as the content of this activity
        setContentView(view)
    }
}
