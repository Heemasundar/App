package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ForgotPasswordPhoneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password_phone)

        val backArrow = findViewById<ImageView>(R.id.backArrow)
        val editPhone = findViewById<EditText>(R.id.editPhone)
        val continueButton = findViewById<Button>(R.id.continueButton)

        backArrow.setOnClickListener { finish() }

        continueButton.setOnClickListener {
            val phone = editPhone.text.toString()

            if (phone.isEmpty()) {
                Toast.makeText(this, "Please enter your phone number", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, OtpVerificationPhoneActivity::class.java)
                intent.putExtra("phone", phone)
                startActivity(intent)
            }
        }
    }
}
