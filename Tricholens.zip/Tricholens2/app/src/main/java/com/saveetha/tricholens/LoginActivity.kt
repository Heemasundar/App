package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val editUsername = findViewById<EditText>(R.id.editUsername)
        val editPassword = findViewById<EditText>(R.id.editPassword)
        val signInButton = findViewById<Button>(R.id.signInButton)
        val forgotPassword = findViewById<TextView>(R.id.forgotPassword)
        val signUpText = findViewById<TextView>(R.id.signUpText)

        signInButton?.setOnClickListener {
            val username = editUsername?.text.toString()
            val password = editPassword?.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            }
        }

        // ✅ Opening Forgot Password (Phone Input Screen)
        forgotPassword?.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordPhoneActivity::class.java))
        }

        signUpText?.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }
}
