package com.saveetha.tricholens

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ObjectDetectedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_object_detected)

        findViewById<ImageView>(R.id.backArrow).setOnClickListener { finish() }
        // If you want to dynamically set image, use:
        // findViewById<ImageView>(R.id.resultImage).setImageResource(R.drawable.your_image)
    }
}
