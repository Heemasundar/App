package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class OtpVerificationPhoneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp_verification_phone)

        val backArrow = findViewById<ImageView>(R.id.backArrow)
        val otp1 = findViewById<EditText>(R.id.otp1)
        val otp2 = findViewById<EditText>(R.id.otp2)
        val otp3 = findViewById<EditText>(R.id.otp3)
        val otp4 = findViewById<EditText>(R.id.otp4)
        val verifyOtpButton = findViewById<Button>(R.id.verifyOtpButton)
        val resendText = findViewById<TextView>(R.id.resendText)

        backArrow.setOnClickListener { finish() }

        verifyOtpButton.setOnClickListener {
            val otp = otp1.text.toString() +
                    otp2.text.toString() +
                    otp3.text.toString() +
                    otp4.text.toString()

            if (otp.length < 4) {
                Toast.makeText(this, "Please enter the full OTP", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "OTP Verified!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, ResetPasswordActivity::class.java))
                finish()
            }
        }

        resendText.setOnClickListener {
            Toast.makeText(this, "OTP Resent", Toast.LENGTH_SHORT).show()
        }
    }
}
