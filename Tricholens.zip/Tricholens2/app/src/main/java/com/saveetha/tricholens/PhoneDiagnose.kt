package com.saveetha.tricholens

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class PhoneDiagnose : AppCompatActivity() {

    private lateinit var scalpImageView: ImageView
    private lateinit var diagnoseButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnose)

        // Initialize views
        scalpImageView = findViewById(R.id.scalpImageView)
        diagnoseButton = findViewById(R.id.diagnoseButton)

        // Load image if passed (optional)
        val imageUriString = intent.getStringExtra("imageUri")
        imageUriString?.let {
            val uri = Uri.parse(it)
            scalpImageView.setImageURI(uri)
        }

        // Click "Diagnose" → Go to ObjectDetectedActivity
        diagnoseButton.setOnClickListener {
            val intent = Intent(this, ObjectDetectedActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
