package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ResetPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)

        val backArrow = findViewById<ImageView>(R.id.backArrow)
        val newPassword = findViewById<EditText>(R.id.newPassword)
        val resetPasswordButton = findViewById<Button>(R.id.resetPasswordButton)

        backArrow.setOnClickListener {
            finish()
        }

        resetPasswordButton.setOnClickListener {
            val password = newPassword.text.toString()
            if (password.isEmpty()) {
                Toast.makeText(this, "Please enter your new password", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Password Successfully Reset!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, ResetSuccessfulActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}
