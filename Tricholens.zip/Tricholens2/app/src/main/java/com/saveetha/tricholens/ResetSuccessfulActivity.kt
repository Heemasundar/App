package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ResetSuccessfulActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_successful)

        val backArrow = findViewById<ImageView>(R.id.backArrow)
        val loginNowButton = findViewById<Button>(R.id.loginNowButton)

        backArrow?.setOnClickListener { finish() }

        loginNowButton?.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
