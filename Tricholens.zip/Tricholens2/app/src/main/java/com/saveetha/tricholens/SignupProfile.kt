package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignupProfile : AppCompatActivity() {

    private lateinit var backArrow: ImageView
    private lateinit var editName: EditText
    private lateinit var editEmail: EditText
    private lateinit var editMobile: EditText
    private lateinit var editDob: EditText
    private lateinit var editCountry: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup_profile)

        backArrow = findViewById(R.id.backArrow)
        editName = findViewById(R.id.editName)
        editEmail = findViewById(R.id.editEmail)
        editMobile = findViewById(R.id.editMobile)
        editDob = findViewById(R.id.editDob)
        editCountry = findViewById(R.id.editCountry)
        saveButton = findViewById(R.id.saveButton)

        backArrow.setOnClickListener { finish() }

        saveButton.setOnClickListener {
            val name = editName.text.toString().trim()
            val email = editEmail.text.toString().trim()
            val mobile = editMobile.text.toString().trim()
            val dob = editDob.text.toString().trim()
            val country = editCountry.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || mobile.isEmpty() || dob.isEmpty() || country.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
