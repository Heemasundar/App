package com.saveetha.tricholens

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ViewProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_profile)

        val backIcon = findViewById<ImageView>(R.id.backIcon)
        val nameText = findViewById<TextView>(R.id.nameText)
        val emailText = findViewById<TextView>(R.id.emailText)
        val phoneText = findViewById<TextView>(R.id.phoneText)
        val dobText = findViewById<TextView>(R.id.dobText)
        val countryText = findViewById<TextView>(R.id.countryText)

        // Example data
        nameText.text = "Jamelia"
        emailText.text = "jamelia@example.com"
        phoneText.text = "+91 9876543210"
        dobText.text = "12-03-1998"
        countryText.text = "India"

        // Back button click
        backIcon.setOnClickListener {
            finish()
        }
    }
}
