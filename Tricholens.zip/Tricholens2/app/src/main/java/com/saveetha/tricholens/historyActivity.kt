package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.history)

        // 🔙 Back Arrow
        val backArrow = findViewById<ImageView>(R.id.backArrow)
        backArrow.setOnClickListener { finish() }

        // 🔍 Search
        val searchEditText = findViewById<EditText>(R.id.searchEditText)

        // 📌 TextViews for names and dates
        val userName1 = findViewById<TextView>(R.id.tvUserName1)
        val date1 = findViewById<TextView>(R.id.tvDate1)

        val userName2 = findViewById<TextView>(R.id.tvUserName2)
        val date2 = findViewById<TextView>(R.id.tvDate2)

        val userName3 = findViewById<TextView>(R.id.tvUserName3)
        val date3 = findViewById<TextView>(R.id.tvDate3)

        // Set values (optional, already set in XML)
        userName1.text = "Jamelia"
        date1.text = "29 Sep 2023  11:45 am"

        userName2.text = "Roy"
        date2.text = "12 Sep 2023  10:03 pm"

        userName3.text = "Amca"
        date3.text = "02 Sep 2023  08:45 pm"

        // 🚀 Open ObjectDetectedActivity when clicking names
        val openDetected = Intent(this, ObjectDetectedActivity::class.java)

        userName1.setOnClickListener { startActivity(openDetected) }
        userName2.setOnClickListener { startActivity(openDetected) }
        userName3.setOnClickListener { startActivity(openDetected) }

        // 🔽 Bottom Navigation
        val profileSection = findViewById<LinearLayout>(R.id.bottomNavigation).getChildAt(0)
        val homeSection = findViewById<LinearLayout>(R.id.bottomNavigation).getChildAt(1)

        profileSection.setOnClickListener {
            startActivity(Intent(this, ViewProfileActivity::class.java))
        }

        homeSection.setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }
    }
}
