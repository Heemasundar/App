package com.saveetha.tricholens.ui.theme

import androidx.compose.ui.graphics.Color

val LightGrayField = Color(0xFFE0E0E0)        // Light gray for EditText backgrounds
val DarkText = Color(0xFF333333)              // Dark text color
val HintText = Color(0xFF888888)              // EditText hint color
val PinkButton = Color(0xFFF8ACAC)            // Pink for Sign up button and accent
val PinkText = Color(0xFFF8ACAC)              // Pink for 'Sign in' link text

// You can still keep the Material default colors if needed
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
