package com.saveetha.tricholens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UpdateProfileActivity : AppCompatActivity() {

    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.update_profile) // Your layout file name

        // Initialize your button
        saveButton = findViewById(R.id.saveButton)

        saveButton.setOnClickListener {
            // Validation or other logic can go here

            // Navigate to Dashboard after update
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
